package com.sosd.insightnews.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.sosd.insightnews.dao.entity.NewsTopicAssociation;

public interface NewsTopicAssociationService extends IService<NewsTopicAssociation> {

}
