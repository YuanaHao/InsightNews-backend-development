package com.sosd.insightnews.service;

public interface AIService {

    String generateTitle(String content);
}
