package com.sosd.insightnews.service;

public interface PermissionService {

}
