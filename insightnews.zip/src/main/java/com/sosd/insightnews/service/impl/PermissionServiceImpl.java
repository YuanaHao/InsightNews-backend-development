package com.sosd.insightnews.service.impl;

import com.sosd.insightnews.service.PermissionService;
import org.springframework.stereotype.Service;

@Service
public class PermissionServiceImpl implements PermissionService {

}




