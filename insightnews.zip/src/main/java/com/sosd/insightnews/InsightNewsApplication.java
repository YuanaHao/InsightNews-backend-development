package com.sosd.insightnews;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InsightNewsApplication {

    public static void main(String[] args) {
        SpringApplication.run(InsightNewsApplication.class, args);
    }

}
