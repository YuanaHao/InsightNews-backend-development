package com.sosd.insightnews.email;



public interface EmailService {

	void send(Email email);
}
