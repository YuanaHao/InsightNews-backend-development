package com.sosd.insightnews.auth.role;

public interface RoleType {
    // 粗粒度角色
    String ADMIN = "Admin";
    String USER = "User";

    // 细粒度角色
    String UserSelf = "UserSelf";
}
