package com.sosd.insightnews.auth.permission;

public interface PermissionOps {

    // edit and delete permission
    String MODIFY_USER = "ModifyUser";


}
