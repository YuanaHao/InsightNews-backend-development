package com.sosd.insightnews.dto;

import lombok.Data;

@Data
public class NewsDetectionReq {

    private String content;
}
