package com.sosd.insightnews;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsightNewsApplicationTests {

    @Test
    void contextLoads() {
    }

}
